import { User } from "../data/db.js";


class UserController {
    //GetAll
    static async index(req, res) {
      const users = await User.find();
      res.status(200).json(users);
    }
    //GetOne
    static async oneUser(req,res){
        const id= req.params.id
        const user= await User.findById(id)
        res.status(200).json(user)
       }

    //Update { $set: req.body}) identifica la parte che voglio cambiare con $set
   static async update(req,res){
    const id= req.params.id
    const updateUser= await User.findByIdAndUpdate(id, { $set: req.body}, {new:true})
    res.status(200).json(updateUser)
   }
   //Delete
   static async delete(req,res){
    const id= req.params.id
    const product= await User.findByIdAndDelete(id)
    res.json("User has been deleted")
   }

 
}

export default UserController