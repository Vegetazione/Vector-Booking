import {Room, Hotel} from "../data/db.js";
import { createError } from "../utilities/error.js";

class RoomController {
  static async createRoom(req, res, next) {
    const hotelId = req.params.hotelid;
    const newRoom = new Room(req.body);
    try {
      const savedRoom = await newRoom.save();
      await Hotel.findByIdAndUpdate(hotelId, {
        $push: { rooms: savedRoom._id },
      });
      res.status(200).json(savedRoom);
    } catch (err) {
      next(err);
    }
  }

  //GetAll
  static async index(req, res) {
    const rooms = await Room.find();
    res.status(200).json(rooms);
  }
  //GetOne
  static async getRoom(req, res) {
    const id = req.params.id;
    const room = await Room.findById(id);
    res.status(200).json(room);
  }

  //Update { $set: req.body}) identifica la parte che voglio cambiare con $set
  static async updateRoom(req, res) {
    const id = req.params.id;
    const updateRoom = await Room.findByIdAndUpdate(
      id,
      { $set: req.body },
      { new: true }
    );
    res.status(200).json(updateRoom);
  }
  //Delete
  static async deleteRoom(req, res) {
    const hotelId = req.params.hotelid;
    await Room.findByIdAndDelete(id);
    await Hotel.findByIdAndUpdate(hotelId,{
        $pull:{ rooms:req.params.id}
    })
    res.json("Room has been deleted");
  }
}

export default RoomController