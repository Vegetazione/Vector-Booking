import { Hotel } from "../data/db.js";



class HotelController {
  //GetAll
  static async index(req, res) {
    const {min,max,...others}=req.query
    const hotels = await Hotel.find({...others, cheapestPrice:{$gt:min | 1, $lt:max ||9999}});//gt= greaterthan lt= lastthen operatori MongodB
    res.status(200).json(hotels);
  }
  //GetOne
  static async oneHotel(req, res) {
    const id = req.params.id;
    const hotel = await Hotel.findById(id);
    res.status(200).json(hotel);
  }

  //Update { $set: req.body}) identifica la parte che voglio cambiare con $set
  static async update(req, res) {
    const id = req.params.id;
    const updateHotel = await Hotel.findByIdAndUpdate(
      id,
      { $set: req.body },
      { new: true }
    );
    res.status(200).json(updateHotel);
  }
  //Delete
  static async delete(req, res) {
    const id = req.params.id;
    const product = await Hotel.findByIdAndDelete(id);
    res.json("Hotel has been deleted");
  }

  //create Giusto
  static async create(req, res) {
    const newHotel = new Hotel(req.body);
    const savedHotel = await newHotel.save();
    res.status(200).json(savedHotel);
  }

  /* SECTION FRONT-END */
  static async countByCity(req, res) {
    const cities = req.query.cities.split(",");
    /* Promise.all per eseguire in parallelo una serie di conteggi di hotel per ciascuna città */
    const list = await Promise.all(
      cities.map((city) => {
        return Hotel.countDocuments({ city: city }); // conta le citta mostra quante sono  come Hotel.find({city:city}).lenght
      })
    );
    res.status(200).json(list);
  }


  static async countByType(req, res) {
    const hotelCount = await Hotel.countDocuments({ type: "hotel" })
    const apartmentCount= await Hotel.countDocuments({ type: "apartment" })
    const resortCount= await Hotel.countDocuments({ type: "resort" })
    const villaCount= await Hotel.countDocuments({ type: "villa" })
    const cabinCount= await Hotel.countDocuments({ type: "cabin" })

    

    res.status(200).json([
      { type:"hotel", count: hotelCount},
      { type: "apartment",count:apartmentCount },
      { type: "resort",count:resortCount },
      { type: "villa",count:villaCount },
      { type: "cabin",count:cabinCount }
    ]);
  }
}

export default HotelController