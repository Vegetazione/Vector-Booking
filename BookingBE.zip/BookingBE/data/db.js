import mongoose from "mongoose";
//url dbATLAS
const url="mongodb+srv://vegetazione:inter123@cluster0.s3v3pbm.mongodb.net/Booking"

//connect
mongoose.connect(url)
.then(()=>console.log("db connected"))
.catch((err)=> console.log(err))


//schema
const HotelSchema =new mongoose.Schema({
  
    name:{type:String, required: true},
    type:{type: String, required: true },
    city:{type: String, required: true },
    address:{type: String, required: true },
    distance:{type: String },
    photos:{type: String },
    desc:{type: String, required: true },
    title:{type: String, required: true },
    rating:{type: Number, min:0 , max:5 },
    rooms:{type: [String], },
    cheapestPrice:{type: Number, required: true },
    featured:{type: Boolean, default: false },
    
})




//Room
const RoomSchema =new mongoose.Schema({
  
    title:{type:String, required: true},
    price:{type: Number, required: true },
    desc:{type: String, required: true },
    maxPeople:{type: Number, required:true },
    roomNumbers: [{number:Number,unavailableDates:{type:[Date]}}], 
    cheapestPrice:{type: Number },
    featured:{type: Boolean, default: false },
    
})

/* esempio di stanza
{number:101,unavailableDates:[01.05.2023,02.05.2023]} 
*/
//Users

const UserSchema =new mongoose.Schema({
    username:{type: String, required: true, unique:true},
    email:{type: String, required: true, unique:true},
    password:{type: String, required: true},
    isAdmin:{type: Boolean, default: false},
   
    
    
},{timestamps: true}) 




//agganciare model
export const Hotel = mongoose.model("Hotel", HotelSchema )
export const User = mongoose.model("User", UserSchema )
export const Room = mongoose.model("Room", RoomSchema )
