import express from "express";
import HotelController from "../controller/HotelController.js";
import { login, register } from "../controller/AuthAdmin.js";
import UserController from "../controller/UsersController.js";
import { verifyAdmin, verifyToken, verifyUser } from "../utilities/verifyToken.js";
import RoomController from "../controller/Roomcontroller.js";

const router = express.Router()

//Controller Hotels
router
.get('/api/hotels',  HotelController.index)
.get('/api/hotels/find/:id', HotelController.oneHotel)
//create

.post('/api/hotels', HotelController.create)
//update
.put('/api/hotels/:id',verifyAdmin, HotelController.update)
//delete
.delete('/api/hotels/:id',verifyAdmin, HotelController.delete)


/* endpoint front-end HOTEL */
router
.get('/api/hotels/countByCity',  HotelController.countByCity)
.get('/api/hotels/countByType',  HotelController.countByType)


//Check Authe +midllewar
router.get('/api/users/check', verifyToken,(req,res,next)=>{
    res.send("Hello User, you are logged in")
})
router.get('/api/users/checkuser/:id', verifyUser,(req,res,next)=>{
    res.send("Hello User, you are logged in and you can delete")
})
router.get('/api/users/checkadmin/:id', verifyAdmin,(req,res,next)=>{
    res.send("Hello Admin, you are logged in and you can delete all")
})


///Controllers Auth
router
.post('/api/auth/register', register)
.post('/api/auth/login', login)

/* Controller Users */

 router
 
 //GET ALL
 .get('/api/users/',verifyAdmin, UserController.index)
 //GET 1
 .get('/api/users/:id',verifyUser, UserController.oneUser)
 //PUT
 .put('/api/users/:id',verifyUser, UserController.update)
 //DELETE
 .delete('/api/users/:id',verifyUser, UserController.delete)



/* Controller Rooms */

router
//CREATE
.post('/api/rooms/:hotelid',verifyAdmin, RoomController.createRoom)
//GET ALL
.get('/api/rooms/', RoomController.index)
//GET 1
.get('/api/rooms/:id', RoomController.getRoom)
//PUT
.put('/api/rooms/:id',verifyAdmin, RoomController.updateRoom)
//DELETE
.delete('/api/rooms/:id/:hotelid',verifyAdmin, RoomController.deleteRoom)










export default router