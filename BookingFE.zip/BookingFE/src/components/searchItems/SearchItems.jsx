import { Link } from "react-router-dom"

function SearchItems({item}) {
  return (
    <>
    <section className="flex  border border-solid rounded-xl p-3 mb-2">
        <img src={item.photos} alt="photo" className="image w-40 h-40 object-cover " />
        <div className="desc flex flex-[2]  flex-col gap-3 mx-2">
           <h1 className="text-[#0071c2] font-bold text-3xl">{item.name}</h1> 
           <span className="text-sm">{item.distance}</span>
           <span className="bg-emerald-800 text-white w-fit p-1 rounded-xl">Free airport taxi</span>
           <span className="font-bold">Studio Apartment</span>
           <span >{item.desc} </span>
           <span className="text-emerald-600 font-sans text-2xl font-bold">Free cancelation</span>
           <span className="text-emerald-400 font-sans text-lg font-bold">You can cancel later</span>
        </div>
        <div className="details border border-solid flex  flex-[1] p-2">
            <div className="sir flex flex-col justify-between ">
                {item.rating &&<div className="rate flex justify-between">
                    <span className="font-bold text-2xl">Excelent</span>
                    <button className="bg-[#003580] text-white font-bold p-1">{item.rating}</button>
                </div>}
                <div className="flex flex-col gap-2 text-right">
                    <span className="price font-bold text-4xl">${item.cheapestPrice}</span>
                    <span className="p font-sans text-sm text-gray-400">Includes taxes and fees</span>
                    <Link to={`http://localhost:5173/hotels/${item._id}`}>
                    <button className="bg-[#0071c2] text-white font-bold p-1 border-none cursor-pointer rounded-lg">See availability</button>
                    </Link>
                </div>
            </div>
        </div>
    </section>
   
   {/*  <section className="flex  border border-solid rounded-xl p-3 mb-2">
        <img src="" alt="" className="image w-40 h-40 object-cover " />
        <div className="desc flex flex-[2]  flex-col gap-3 mx-2">
           <h1 className="text-[#0071c2] font-bold text-3xl">Tower Street Apartment</h1> 
           <span className="text-sm">500 m from center</span>
           <span className="bg-emerald-800 text-white w-fit p-1 rounded-xl">Free airport taxi</span>
           <span className="font-bold">Studio Apartment</span>
           <span >Entire studio ◉ 1 Bathroom ◉ 44m² ◉ 1 Full bed </span>
           <span className="text-emerald-600 font-sans text-2xl font-bold">Free cancelation</span>
           <span className="text-emerald-400 font-sans text-lg font-bold">You can cancel later</span>
        </div>
        <div className="details border border-solid flex  flex-[1] p-2">
            <div className="sir flex flex-col justify-between ">
                <div className="rate flex justify-between">
                    <span className="font-bold text-2xl">Excelent</span>
                    <button className="bg-[#003580] text-white font-bold p-1">8.9</button>
                </div>
                <div className="flex flex-col gap-2 text-right">
                    <span className="price font-bold text-4xl">112$</span>
                    <span className="p font-sans text-sm text-gray-400">Includes taxes and fees</span>
                    <button className="bg-[#0071c2] text-white font-bold p-1 border-none cursor-pointer rounded-lg">See availability</button>
                </div>
            </div>
        </div>
    </section> */}
    </>
  )
}

export default SearchItems