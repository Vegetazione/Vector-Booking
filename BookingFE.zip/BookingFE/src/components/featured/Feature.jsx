import useFetch from "../../hooks/useFetch";


function Feature() {
   const {data}=useFetch("http://localhost:8080/api/hotels/countByCity?cities=roma,madrid,london,amsterdam,berlin")
   console.log(data);
  return (
    <div className="featured w-full max-w-5xl flex justify-between gap-8  ">
        <div className="featureditem   w-1/5  text-[#2c5d3d] rounded-xl overflow-hidden">
            <img className="w-48 h-48" src="https://image.urlaubspiraten.de/640/image/upload/v1677050252/Impressions%20and%20Other%20Assets/shutterstock_2111345756_gl17pk.jpg" alt="img" />
            <div className="featuredtitle  ">
                <h1 className="font-bold text-3xl">Berlin</h1>
                <h2 className="font-medium  text-xl">{data[4]} properties</h2>
            </div>
        </div>
        <div className=" w-1/5  text-[#c03d46] rounded-xl overflow-hidden">
            <img className="w-48 h-48" src="https://staticgeopop.akamaized.net/wp-content/uploads/sites/32/2022/10/iStock-177303568.jpg?im=AspectCrop=(16,9);" alt="img" />
            <div className="featuredtitle  bottom-2">
                <h1 className="font-bold text-3xl">Rome</h1>
                <h2 className="font-medium text-xl">{data[0]} properties</h2>
            </div>
        </div>
        <div className="relative w-1/5  text-[#0071c2] rounded-xl overflow-hidden">
            
            <div className="featuredtitle">
                 <img className="w-48 h-48" src="https://cdn.tiqets.com/wordpress/blog/wp-content/uploads/2022/07/17160538/thingstodoinmadrid-1-1.jpg" alt="img" />
                <h1 className="font-bold text-3xl">Madrid</h1>
                <h2 className="font-medium text-xl">{data[1]} properties</h2>
            </div>
        </div>
        <div className="relative w-1/5  text-[#0f181f] rounded-xl overflow-hidden">
            <img className="w-48 h-48" src="https://www.lastrolabio.it/wp-content/uploads/2021/09/visitare-londra.jpg" alt="img" />
            <div className="featuredtitle  ">
                <h1 className="font-bold text-3xl">London</h1>
                <h2 className="font-medium text-xl">{data[2]} properties</h2>
            </div>
        </div>
        <div className="relative w-1/5  text-[#246b42] rounded-xl overflow-hidden">
        <img className="w-48 h-48" src="https://miro.medium.com/v2/resize:fit:1400/1*yrIfk0wPO9PgWiN-XEPOwA.jpeg" alt="img" />
            <div className="featuredtitle ">
                <h1 className="font-bold text-3xl">Amsterdam</h1>
                <h2 className="font-medium text-xl">{data[3]} properties</h2>
            </div>
        </div>
    </div>
  )
}

export default Feature