import { useContext } from "react";
import { Link } from "react-router-dom"
import { AuthContext } from "../../context/AuthContext.jsx";
function Navbar() {
  const { user,dispatch } = useContext(AuthContext);
  const handleLogout = () => {
    // Effettua il logout reimpostando lo stato dell'utente su null
    dispatch({ type: "LOGOUT" });
  };
  
  return (
    <section className="h-[60px] bg-[#003580]  flex justify-center">
        <div className="w-full max-w-5xl  text-white flex items-center justify-between ">
            <Link to="/">
            <span className="text-5xl font-bold">Vector Booking</span>
            </Link>
            {user ? (
             <span>{user.username}
               <button className="m-4 p-2 cursor-pointer color-[#003580] border bg-white text-[#003580] border-white rounded-md font-bold" onClick={handleLogout}>Logout</button>
             </span>
          
             
            
        ) : (
          <div className="navItems">
            
            <Link to="/login">
              <button className="m-4 p-2 cursor-pointer color-[#003580] border bg-white text-[#003580] border-white rounded-md font-bold">Login</button>
            </Link>
          </div>
        )}
        </div>
    </section>
  )
}

export default Navbar