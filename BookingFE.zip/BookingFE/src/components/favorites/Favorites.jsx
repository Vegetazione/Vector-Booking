import { Link } from "react-router-dom";
import useFetch from "../../hooks/useFetch";


function Favorites() {
  const {data}=useFetch("http://localhost:8080/api/hotels?featured=true")
  return (
    <section className=" w-full max-w-5xl flex justify-between gap-8 my-4 ">
       {data &&
        data.map((item) => (
          <div className="flex flex-col items-center gap-2 " key={item._id}>
           
            <img className="rounded-3xl w-full h-64 object-cover shadow-black shadow-md"
          src={item.photos}
          alt="HotelImg"
        />
      
        <span className="text-3xl font-serif font-semibold  text-[#003580]">{item.name}</span>
        <span className=" text-3xl capitalize font-semibold ">{item.city}</span>
        <span className="text-2xl font-serif">Start for $ <b className="text-emerald-500">{item.cheapestPrice}</b></span>
        {item.rating &&<div className="rate">
          <button className="bg-[#003580] text-black border-none p-1 font-bold mr-2">{item.rating}</button>
          <span>Excelent</span>
        </div>}
      </div>
        ))}
      
    </section>
  );
}

export default Favorites