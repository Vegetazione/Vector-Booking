import {
  faBed,
  faCalendarDays,
  faCar,
  faPerson,
  faPlane,
  faTaxi,
} from "@fortawesome/free-solid-svg-icons";
import { DateRange } from "react-date-range";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { useState } from "react";
import 'react-date-range/dist/styles.css'; // main css file
import 'react-date-range/dist/theme/default.css'; // theme css file
import { format } from "date-fns";
import { useNavigate } from "react-router-dom";
/* type prop lo uso per render versatile l'Header e customizzabile (80) */
function Header({ type }) {
  /* Logic Component */
  const [destination, setDestination] = useState("");
  const [openOptions, setOpenOptions] = useState(false);
  const [options, setOptions] = useState({
    adult: 1,
    children: 0,
    rooms: 1,
  });

  /* date calendar */
const  [openDate, setOpenDate]=useState(false)
const [date, setDate] = useState([
    {
      startDate: new Date(),
      endDate: new Date(),
      key: 'selection'
    }
  ]);

  const navigate = useNavigate();

  /* function Button */
  function optionButton(name, operation) {
    setOptions((prev) => {
      return {
        ...prev,
        [name]: operation === "i" ? options[name] + 1 : options[name] - 1,
      };
    });
  }

  /* function Search */
  function searchBtn() {
    navigate("/hotels", { state: { destination, date, options } });
  }

  return (
    <main className="bg-[#003580] text-white flex justify-center relative ">
      <section className="w-full max-w-5xl mt-4 mb-24 ">
        <div className=" flex gap-8">
          <div className=" flex items-center gap-4 active:border border-solid border-white p-3 rounded-xl">
            <FontAwesomeIcon icon={faBed} />
            <span>Stays</span>
          </div>
          <div className=" flex items-center gap-4">
            <FontAwesomeIcon icon={faPlane} />
            <span>Flights</span>
          </div>
          <div className=" flex items-center gap-4">
            <FontAwesomeIcon icon={faCar} />
            <span>Car Rent</span>
          </div>
          <div className=" flex items-center gap-4">
            <FontAwesomeIcon icon={faBed} />
            <span>Attractions</span>
          </div>
          <div className=" flex items-center gap-4">
            <FontAwesomeIcon icon={faTaxi} />
            <span>Airport Taxi</span>
          </div>
        </div>
        {/* Search item */}
        {type !== "list" && (
          <>
            <div className="flex flex-col gap-8 mt-4">
              <h1 className="font-serif text-4xl ">
                The ideal vacation, your way
              </h1>
              <p className=" font-light text-xl">
                Save 15% or more on your stay, from relaxing holidays to
                adventures away from it all
              </p>
              <button className="bg-[#0071c2] text-white border-none p-4 w-60 cursor-pointer">
                Find your ideal vacation
              </button>
            </div>
            <div className="flex items-center text-black justify-around p-6 h-8 bg-white border border-solid border-[#febb02] gap-8 mt-4 absolute bottom-[-22px] w-full max-w-5xl">
              <div className="search items-center flex gap-3">
                <FontAwesomeIcon icon={faBed} style={{ color: "#7c8088" }} />
                <input
                  className="outline-none border-none"
                  type="text"
                  placeholder="Where are you going?"
                  onChange={(e) => setDestination(e.target.value)}
                />
              </div>
              <div className="search items-center flex gap-3 ">
                <FontAwesomeIcon
                  icon={faCalendarDays}
                  style={{ color: "#7c8088" }}
                />
                <span onClick={()=>setOpenDate(!openDate)}>{`${format(date[0].startDate, "dd/MM/yyyy")} to ${format(date[0].endDate, "dd/MM/yyyy")}`}</span>
                {/* chiedere ReactDateRange se va bene */}
              {openDate &&  <DateRange
                  editableDateInputs={true}
                  onChange={(item) => setDate([item.selection])}
                  moveRangeOnFirstSelection={false}
                  ranges={date}
                  className="absolute top-12 z-[4]"
                  minDate={new Date()}
                />}
              </div>
              <div className=" cursor-pointer items-center flex gap-3 ">
                <FontAwesomeIcon icon={faPerson} style={{ color: "#7c8088" }} />
                <span onClick={() => setOpenOptions(!openOptions)}>
                  {`${options.adult} Adult - ${options.children} Children - ${options.rooms} Room`}
                </span>
                {/* opzioni Viaggio */}
                {openOptions && (
                  <div className="option absolute z-[2] top-12 p-4  bg-white text-black rounded-md shadow-md shadow-black">
                    <div className="optionItems flex justify-between w-80 mb-4 ">
                      <span className="optiontext">Adult </span>
                      <div className="flex items-center gap-3">
                        <button
                          disabled={options.adult <= 1}
                          className="optionCounterButton w-6 h-6 border border-solid border-[#0071c2] cursor-pointer bg-white"
                          onClick={() => optionButton("adult", "d")}
                        >
                          {" "}
                          -
                        </button>
                        <span className="optionCounterNumber">
                          {" "}
                          {options.adult}{" "}
                        </span>
                        <button
                          className="optionCounterButton w-6 h-6 border border-solid border-[#0071c2] cursor-pointer bg-white"
                          onClick={() => optionButton("adult", "i")}
                        >
                          {" "}
                          +
                        </button>
                      </div>
                    </div>
                    <div className="optionItems flex justify-between w-80 mb-4">
                      <span className="optiontext">Children </span>
                      <div className="flex items-center gap-3">
                        <button
                          disabled={options.children <= 0}
                          className="optionCounterButton w-6 h-6 border border-solid border-[#0071c2] cursor-pointer bg-white"
                          onClick={() => optionButton("children", "d")}
                        >
                          {" "}
                          -{" "}
                        </button>
                        <span className="optionCounterNumber">
                          {" "}
                          {options.children}{" "}
                        </span>
                        <button
                          className="optionCounterButton w-6 h-6 border border-solid border-[#0071c2] cursor-pointer bg-white"
                          onClick={() => optionButton("children", "i")}
                        >
                          {" "}
                          +{" "}
                        </button>
                      </div>
                    </div>
                    <div className="optionItems flex justify-between w-80 mb-4">
                      <span className="optiontext">Room </span>
                      <div className="flex items-center gap-3">
                        <button
                          disabled={options.rooms <= 1}
                          className="optionCounterButton w-6 h-6 border border-solid border-[#0071c2] cursor-pointer bg-white"
                          onClick={() => optionButton("rooms", "d")}
                        >
                          {" "}
                          -{" "}
                        </button>
                        <span className="optionCounterNumber">
                          {" "}
                          {options.rooms}{" "}
                        </span>
                        <button
                          className="optionCounterButton w-6 h-6 border border-solid border-[#0071c2] cursor-pointer bg-white"
                          onClick={() => optionButton("rooms", "i")}
                        >
                          {" "}
                          +{" "}
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
              {/* Button Search */}
              <div>
                <button
                  className="bg-[#003580] text-white border p-1.5"
                  onClick={searchBtn}
                >
                  Search
                </button>
              </div>
            </div>
          </>
        )}
      </section>
    </main>
  );
}

export default Header;
