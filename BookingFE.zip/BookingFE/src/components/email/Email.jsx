
function Email() {
  return (
    <section>
        <div className="w-full mt-10 bg-[#003580] text-white flex flex-col item-center gap-5 p-10">
            <h1 className="text-3xl font-bold">Save time,save money!</h1>
            <h2 className="text-xl">Sign up and we will send the best deals to you</h2>
            <div>
                <input className="p-2 rounded-xl" type="text" placeholder="Insert your Email" />
                <button className="mx-4 bg-white text-[#003580] font-bold p-2 rounded-xl border-none">Subscribe</button>
            </div>
        </div>
    </section>
  )
}

export default Email