import useFetch from "../../hooks/useFetch";


function PropertyList() {
    const { data }= useFetch("http://localhost:8080/api/hotels/countByType")

    const images= [
        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSgmEL92loF4IqsJzAmySa3_OGVjqm-866MLw&usqp=CAU",
        "https://www.common.com/_next/image?url=%2Fimages%2Fsplash-page.jpeg&w=3840&q=75",
        "https://images.cdn.itravel.de/Bgly7twk2HajArzE8qREyX5NLV0=/1000x667/https://nucleo-en-production.s3.eu-central-1.amazonaws.com/F5C572168E8FB9CF675BA63B8651375E.jpg",
        "https://tabairarealestate.com/media/images/properties/thumbnails/o_1cggkfceo1s0mq7ireblsjrj71c_w_1300x650.jpg",
        "https://media.bizj.us/view/img/12293308/processed-3803*1200xx2500-1406-0-131.jpg"
    ]
  
  return (
    <section>
    <div className="max-w-5xl flex justify-between items-center gap-5 ">
      {data &&
        data.map((item, i) => (
          <div className="flex flex-col items-center rounded-xl gap-2 overflow-hidden cursor-pointer" key={i}>
            <img className="w-full h-[150px] object-cover" src={images[i]} alt="Hotel" />
            <div className="listTitle">
              <h1 className="font-bold text-3xl mt-2 capitalize">{item.type}</h1>
              <h2 className="text-neutral-400 text-xl mt-2 capitalize">{item.count} {item.type}</h2>
            </div>
          </div>
        ))}
    </div>
  </section>
);
}

export default PropertyList