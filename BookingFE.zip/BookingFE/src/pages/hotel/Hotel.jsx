import Navbar from "../../components/navbar/Navbar";
import Header from "../../components/header/Header";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faLocationDot } from "@fortawesome/free-solid-svg-icons";
import Footer from "../../components/footer/Footer";
import useFetch from "../../hooks/useFetch";
import { useLocation } from "react-router-dom";

function Hotel() {
  const location = useLocation();
  console.log(location);
  const id = location.pathname.split("/")[2];
  const { data } = useFetch(`http://localhost:8080/api/hotels/find/${id}`);

  return (
    <section>
      <Navbar />
      <Header type="list" />
      <div className="hotelCont flex items-center justify-center ">
        <div className="shadow shadow-black m-8 border-black max-w-5xl flex flex-col gap-4 relative p-10">
          <button className="absolute top-2 right-0 p-3 m-4 bg-[#0071c2] text-white font-bold cursor-pointer rounded-md">
            Reserve or Boook Now
          </button>
          <h1 className="text-3xl font-serif ">{data.name}</h1>
          <div className="hadress flex items-center gap-3">
            <FontAwesomeIcon icon={faLocationDot} />
            <span>{data.address}</span>
          </div>
          <span className=" font-semibold">{data.distance}</span>
          <span className="text-emerald-700 font-semibold">
            Book a stay over ${data.cheapestPrice} at this property and get a
            free airport taxi
          </span>
          <div className="hImages flex flex-wrap justify-between ">
            <div className="w-1/2 m-1 ">
              <img
                src={data.photos}
                alt="img"
                className="w-full h-full object-cover  "
              />
            </div>
          </div>
          <div className="hDetails flex justify-between gap-5 mt-2">
            <div className="text w-1/2">
              <h1 className="font-bold text-2xl">{data.title}</h1>
              <p className="text-xl mt-4">
                {data.desc} <br />
                
              </p>
            </div>
            <div className="price bg-[#dce7f8] p-4 flex flex-col gap-4">
              <h1 className="text-3xl font-bold text-gray-600">
                Perfect for your Travel
              </h1>
              <span className="font-sans font-semibold text-md">
                Good choice!! Your reservation comes on the day:
              </span>
              <h2 className="text-2xl text-center ">
                {" "}
                <b>${data.cheapestPrice}/day</b>
              </h2>
              <button className="p-3 bg-[#0071c2] text-white font-bold cursor-pointer rounded-md">
                Reserve or Book Now!!!
              </button>
            </div>
          </div>
        </div>
      </div>
      <footer className="bg-[#003580]   p-4 text-white w-full">
        <Footer />
      </footer>
    </section>
  );
}

export default Hotel;
