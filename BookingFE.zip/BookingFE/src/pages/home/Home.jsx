import Email from "../../components/email/Email"
import Favorites from "../../components/favorites/Favorites"
import Feature from "../../components/featured/Feature"
import Footer from "../../components/footer/Footer"
import Header from "../../components/header/Header"
import Navbar from "../../components/navbar/Navbar"
import PropertyList from "../../components/propertyList/PropertyList"

function Home() {
  return (
    <section>
      <Navbar />
      <Header />
      <div className="flex flex-col items-center gap-10 mt-2 p-10">
        <Feature />
        <h1 className="w-[1024px] text-5xl text-[#003580] font-serif font-bold mt-4">
          Browse by Property Type
        </h1>
        <PropertyList />
        <h1 className="w-[1024px] text-5xl text-[#003580] font-serif font-bold mt-4">
        The most loved
        </h1>
        <Favorites />
      </div>
      <div className="flex flex-col justify-center text-center">
        <Email />
      </div>
      <footer>
        <Footer/>
      </footer>
    </section>
  );
}

export default Home