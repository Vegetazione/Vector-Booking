import { useLocation } from "react-router-dom"
import Header from "../../components/header/Header"
import Navbar from "../../components/navbar/Navbar"
import { useState } from "react";
import { format } from "date-fns";
import { DateRange } from "react-date-range";
import SearchItems from "../../components/searchItems/SearchItems";
import useFetch from "../../hooks/useFetch";

function List() {
  /* fondamentale */
  const location = useLocation()
  console.log(location);
  const [destination,setDestination]= useState(location.state.destination)
  const [date,setDate]= useState(location.state.date)
  const [openDate,setOpenDate]= useState(false)
  const [options,setOptions]= useState(location.state.options)
  const [min,setMin]= useState(undefined)
  const [max,setMax]= useState(undefined)

  const {data, reFetch}=useFetch(`http://localhost:8080/api/hotels?city=${destination}&min=${min ||1}&max=${max ||9999}`)
  /* function */
  function click() {
    reFetch()
  }


  return (
    <div>
    <Navbar/>
    <Header type="list" />
    <div className="listcontainer flex justify-center mt-5 ">
      <div className="wrapper flex w-full max-w-5xl gap-4 ">
        <div className="listsearch flex flex-col w-1/3 bg-[#febb02] p-2 rounde-xl font-bold sticky top-3 h-max ">
          <h1 className="text-[#555] text-4xl mb-3 font-bold">Search</h1>
          <div className="flex flex-col gap-2 mb-2">
            <label htmlFor="">Destination</label>
            <input className="p-3 h-8" placeholder={destination}  type="text" />
          </div>
          <div className="flex flex-col gap-2 mb-2">
            <label htmlFor="">Check-in Date</label>
            <span onClick={()=>setOpenDate(!openDate)} className="h-8 p-2 flex items-center bg-white cursor-pointer">{`${format(date[0].startDate, "dd/MM/yyyy")} to ${format(date[0].endDate, "dd/MM/yyyy")}`}</span>
           {openDate && (<DateRange 
            onChange={item=>setDate([item.selection])}
             minDate={new Date()}
             ranges={date}
             className=""
            />
            )}
          </div>
          <div className="flex flex-col gap-2 mb-2">
             <label htmlFor="">Options</label> 
             <div className=" flex justify-between mb-2 text-[#555]">
              <span className="text">
                Min Price per night
              </span>
              <input min={1} type="number" onChange={e=>setMin(e.target.value)} className="" />
             </div>
             <div className=" flex justify-between mb-2 text-[#555]">
              <span className="text">
                Max Price per night
              </span>
              <input min={1} type="number" onChange={e=>setMax(e.target.value)} className="" />
             </div>
             <div className=" flex justify-between mb-2 text-[#555]">
              <span className="text">
               Adult
              </span>
              <input type="number" min={1} className="" placeholder={options.adult} />
             </div>
             <div className=" flex justify-between mb-2 text-[#555]" >
              <span className="text">
                Children
              </span>
              <input type="number" min={0} className="" placeholder={options.children} />
             </div>
             <div className=" flex justify-between mb-2 text-[#555]">
              <span className="text">
                Rooms
              </span>
              <input type="number" min={1} className="" placeholder={options.rooms}/>
             </div>
          </div>
          <button onClick={click}
          className="p-2 bg-[#0071c2] text-white  rounded-xl font-bold font-serif hover:bg-emerald-500">
            Search
          </button>
        </div>
        <div className="listresult w-2/3 ">
          {data.map(item=>(
            <SearchItems item={item} key={item._id}/>
          ))}
          
        </div>
      </div>
    </div>
    </div>
  )
}

export default List