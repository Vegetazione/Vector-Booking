import axios from "axios";
import { useContext, useState } from "react";
import { useNavigate } from "react-router-dom";
import { AuthContext } from "../../context/AuthContext";


const Login = () => {
  const [credentials, setCredentials] = useState({
    username: undefined,
    password: undefined,
  });

  const { loading, error, dispatch } = useContext(AuthContext);

  const navigate = useNavigate()

  function inputChange(e) {
        setCredentials((prev) => ({ ...prev, [e.target.id]: e.target.value }));
    }

  async function loginClick(e) {
        e.preventDefault();
        dispatch({ type: "LOGIN_START" });
        try {
            const res = await axios.post("http://localhost:8080/api/auth/login", credentials);
            dispatch({ type: "LOGIN_SUCCESS", payload: res.data });
            navigate("/");//go to homePage
        } catch (err) {
            dispatch({ type: "LOGIN_FAILURE", payload: err.response.data });
        }
    }


  return (
    <div className="h-[100vh] flex items-center justify-center">
      <div className="lContainer flex flex-col gap-3">
        <h1 className="text-center text-3xl font-sans font-bold">Sign In</h1>
        <input
          type="text"
          placeholder="username"
          id="username"
          onChange={inputChange}
          className="h-10 p-3 border border-black rounded-lg "
        />
        <input
          type="password"
          placeholder="password"
          id="password"
          onChange={inputChange}
          className="h-10 p-3 border border-black rounded-lg "
        />
        <button disabled={loading} onClick={loginClick} className="border-none p-4 bg-[#0071c2] font-bold cursor-pointer rounded-md hover:bg-emerald-600 text-white">
          Login
        </button>
        {error && <span>{error.message}</span>}
      </div>
    </div>
  );
};

export default Login;
